from functools import reduce
def func_list(a:list,b:int):
    return [(b,x) for x in a]
a= [1,2,3]
lst = [1.2,3,4,2,'a',5.31] 
b= 4
# print(func_list(a,b))
def func_list_2(a:list,b:int):
    return list(map(lambda x :(b,x), a))
# print(func_list_2(a,b))
def func_list_3(a:list,b:int):
    return [(b,a[0])]+func_list_3(a[1:],b) if a else []
# print(func_list_3(a,b))
def mul_int(lst):
    mul = 1
    for x in lst:
        if type(x) == int:
            mul  = mul *x
    return mul
# print(mul_int(lst))
def mul_int_2(lst):
    m = 1 
    for x in filter(lambda x: type(x)==int,lst):
        m=m*x
    return m
# print(mul_int_2(lst))
def mul_int_3(lst):
    if lst:
        for x in lst:
            if type(x) == int:
                return x* mul_int_3(lst[1:])
            else:
                mul_int_3(lst[1:])
    else:
        return 1;

# print(mul_int_3(lst))
def sum_list(lst):
    l1=[]
    n=len(lst)
    for x in range(n):
        l1.append(sum(lst[:x+1]))
    return l1
lst2=[1,2,3,4]

def sum_list_2(lst):
    return [lst2[0]] + [reduce(lambda x,y:x+y,lst[:i+2]) for i in range(len(lst)-1)]
print(sum_list_2(lst2))


def ham1(lst):
    return reduce(lambda x,y: x*y,list(filter(lambda x: type(x)==int,lst)),1)
def ham2(lst):
    return reduce(lambda x,y: x*y, [x for x in lst if type(x) == int])
def ham3(lst):
    return (lst[0] * ham3(lst[1:]) if type(lst[0])==int else ham3(lst[1:])) if lst else 1

lst5 = [1.2,'a',2,5.31,'asd',4]
# print(ham1(lst5))
#Sum list recursion

