from functools import reduce
def compose(*g):
    return lambda args: (reduce (lambda x,y:y(x),g[::-1],args))
def square(x):
    return x*x
def increase(x):
    return x+1
def double(x):
    return 2*x
m = compose(square,increase,double)
print(m(5))
#compose recursion
def compose_recur(*g):
    # if len(g) == 1:
    #     return lambda x: g[0](x)
    # return lambda x: g[0](compose_recur(*g[:1])(x))
    if len(g)==1:
        return lambda x:g[0](x)
    return lambda x:g[0](compose_recur(*g[1:])(x))
n= compose_recur(square,increase,double)
# print(n(5)) 
def list_reduce(lst):
    return reduce(lambda x, y: x + y,map(str,lst))
lst = ['a' , 3 ,'1.e2','h']
print(list_reduce(lst))