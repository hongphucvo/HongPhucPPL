import unittest
from TestUtils import TestLexer

class LexerSuite(unittest.TestCase):
      
    # def test_lower_identifier(self):
    #     """test identifiers"""
    #     self.assertTrue(TestLexer.checkLexeme("abc","abc,<EOF>",101))
    # def test_lower_upper_id(self):
    #     self.assertTrue(TestLexer.checkLexeme("aCBbdc","aCBbdc,<EOF>",102))
    # def test_wrong_token(self):
    #     self.assertTrue(TestLexer.checkLexeme("aA?sVN","aA,Error Token ?",103))
    # def test_integer(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme("123a123","123,a,123,<EOF>",104))
    # def test_integer(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme("00","0,0,<EOF>",104))
    #     self.assertTrue(TestLexer.checkLexeme("1021","1021,<EOF>",105))
    #     self.assertTrue(TestLexer.checkLexeme("900","900,<EOF>",106))
    #     self.assertTrue(TestLexer.checkLexeme("0","0,<EOF>",107))
    #     self.assertTrue(TestLexer.checkLexeme("0123","0,123,<EOF>",108))
    # def test_string(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme('""aa""','""aa"",<EOF>',109))
    # def test_string1(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme('""abc " de"f""','""abc " de"f"",<EOF>',110))
    # def test_string2(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme('""abc " ""','""abc " "",<EOF>',111))
    def test_password(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme('minhNung2sd','minhNung2sd,<EOF>',112))
    # def test_password1(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme('?c','?c,<EOF>',113))
    def test_string(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme("''adsd''","''adsd'',<EOF>",114))
    def test_string1(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme("''as'sd''","''as'sd'',<EOF>",115))
    def test_password2(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme('a2A','a2A,<EOF>',116))
    # def test_password3(self):
    #     """test integers"""
    #     self.assertTrue(TestLexer.checkLexeme('d2zxcx','d2zxcx,<EOF>',117))  
    def test_an(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme('+=','+=,<EOF>',118))    
    


        