#test closure
def power(x):
    # return lambda y: y ** x
    def foo(y):
        return y**x
    return foo
a= power(2)
print(a)
print(a(3))
from functools import reduce
def subsum(lst):
    return list(map(lambda x: sum(lst[:x+1]),[x for x in range(len(lst))]))
def subsum1(lst):
    return [reduce(lambda x,y: x+y,lst[:i+1]) for i in range(len(lst))]
lst= [1,3,4,5]
print(subsum(lst))
print(subsum1(lst))
def subsum2(lst):
    lst1=[]
    for i in range(len(lst)):
        lst1.append(sum(lst[:i+1]))
    return lst1    
# print(subsum2(lst))
#test function as parameters
def subsum3(lst):
    return subsum3(lst[:-1]) + [sum(lst)] if lst else []
print(subsum3(lst))
def increase(x):
    return x+1
def square(y):
    return y*y
l1=[increase,square]
# print(list(map(lambda x: x(3),l1)))
#test currying function
def plus(x):
    def foo1(y):
        def foo2(z):
            return x+y+z
        return foo2
    return foo1
# b = plus(1)
# print(b)
# print(b(2)(3))
#test lazy evaluation
# a =0
# def lazy_evaluation(b:bool,x:int,y:int):
#     return x if (b) else y
# f=lazy_evaluation(True,1,1/a)
# print(f)