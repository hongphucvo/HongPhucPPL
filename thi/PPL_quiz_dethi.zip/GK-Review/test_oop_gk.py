class A:
    def accept(self,v):
        v.visitA(self)
        print("A")
class B(A):
    def accept(self, v):
        v.visitB(self)
        print("B")
class C:
    def accept(self,v):
        v.visitC(self)
        print("C")
class Visitor:
    def visitA(self,x):
        print("visitA")
        return x.accept(self)
    def visitB(self,x):
        print("visitB")
    def visitC(self,x):
        print("visitC")

